import 'package:flutter/material.dart';
import 'package:estudo_dirigido/destaque.dart';
import 'package:estudo_dirigido/marcas.dart';

class home extends StatefulWidget
{
  const home({Key? key}) : super(key: key);

  @override
  _homeState createState() => _homeState();
}

class _homeState extends State<home>
{
  @override
  Widget build(BuildContext context)
  {
    return Scaffold
      (
      appBar: new AppBar
        (
          iconTheme: IconThemeData(color: Colors.white),
          title: const Text('Johnattan Venue', style: TextStyle(color: Colors.white)),
          backgroundColor: Colors.deepPurple,
        ),
      body: Center
        (
        child: Column
          (
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>
            [
            Image.asset
              (
                "imagens/nikee.jpg",
                width: 300,
                height: 200,
              ),
            Text("Camiseta Nike Sportswear Masculina"),
            //ignore: deprecated_member_use
            RaisedButton
              (
                child: Text("Destaque"),
                color: Colors.deepPurple,
                padding: EdgeInsets.all(25
                ),
                  onPressed:()
                  {
                    Navigator.push(context, MaterialPageRoute
                      (
                        builder: (context) => perifericos()
                      ),
                  );
                  }
              ),
              RaisedButton(
                  child: Text("Marcas que utilizamos"),
                  color: Colors.deepPurple,
                  padding: EdgeInsets.all(20),
                  onPressed:(){
                    Navigator.push(context, MaterialPageRoute(
                        builder: (context) => pc()
                    ),
                    );
                  }
              ),
            ],
          ),
        ),
      );
  }
}
