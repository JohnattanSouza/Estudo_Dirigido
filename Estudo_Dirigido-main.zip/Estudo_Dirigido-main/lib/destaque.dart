import 'package:estudo_dirigido/home.dart';
import 'package:flutter/material.dart';

class perifericos extends StatefulWidget
{
  const perifericos({Key? key}) : super(key: key);

  @override
  _perifericosState createState() => _perifericosState();
}

class _perifericosState extends State<perifericos>
{
  @override
  Widget build(BuildContext context)
  {
    return Scaffold
      (
        appBar: new AppBar
          (
            iconTheme: IconThemeData(color: Colors.white),
            title: const Text('Camisa em destaque', style: TextStyle(color: Colors.black)),
            backgroundColor: Colors.deepPurple,
          ),

      body: ListView(
        children: <Widget>
        [
          Image.asset
            (
              "imagens/nike.png",
            ),

          ListTile
            (
              leading: Icon(Icons.add_alert),
              title: Text("Ativar Notificação"),
            ),

          ListTile
            (
              leading: Icon(Icons.add),
              title: Text("Adicionar Informações"),
            ),

          ListTile
            (
              leading: Icon(Icons.add_photo_alternate_outlined),
              title: Text("Adicionar Foto"),
            ),

          ListTile
            (
              leading: Icon(Icons.arrow_downward_sharp),
              title: Text("Baixar Informações"),
            ),

          RaisedButton
            (
              child: Text("Retornar"),
              color: Colors.deepPurple,
              padding: EdgeInsets.all(20),
              onPressed:()
              {
                Navigator.push(context, MaterialPageRoute
                  (
                      builder: (context) => home()
                  ),
                );
              }
            ),
        ],
      ),
      );
    }
}